"""
Conexión y esquema SQLite de SIGPET.

La base de datos se crea en database/sigpet.db.
SQLite se utiliza en esta etapa para disponer de transacciones ACID
sin instalar dependencias externas. La clase encapsula la conexión
para facilitar una futura migración a SQLAlchemy/MySQL.
"""
import sqlite3
from pathlib import Path


class DatabaseConnection:
    def __init__(self, database_name="sigpet.db"):
        self.database_path = Path(__file__).resolve().parent / database_name

    def connect(self):
        connection = sqlite3.connect(
            self.database_path,
            timeout=10,
            isolation_level=None
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def initialize(self):
        """Crea tablas y aplica una migración compatible con la versión previa."""
        with self.connect() as connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS equipos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    codigo TEXT NOT NULL UNIQUE,
                    nombre TEXT NOT NULL,
                    categoria TEXT NOT NULL,
                    estado TEXT NOT NULL DEFAULT 'DISPONIBLE'
                )
            """)

            connection.execute("""
                CREATE TABLE IF NOT EXISTS prestamos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    equipo_id INTEGER NOT NULL,
                    usuario_id INTEGER NOT NULL,
                    fecha_devolucion_esperada TEXT NOT NULL,
                    observaciones TEXT,
                    estado TEXT NOT NULL DEFAULT 'ACTIVO',
                    fecha_devolucion_real TEXT,
                    FOREIGN KEY (equipo_id) REFERENCES equipos(id)
                )
            """)

            connection.execute("""
                CREATE TABLE IF NOT EXISTS devoluciones (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    prestamo_id INTEGER NOT NULL UNIQUE,
                    fecha_devolucion TEXT NOT NULL,
                    observaciones TEXT,
                    FOREIGN KEY (prestamo_id) REFERENCES prestamos(id)
                )
            """)

            # Migración para bases creadas con la versión anterior del proyecto.
            columns = {
                row["name"]
                for row in connection.execute(
                    "PRAGMA table_info(prestamos)"
                ).fetchall()
            }
            if "fecha_devolucion_real" not in columns:
                connection.execute(
                    "ALTER TABLE prestamos ADD COLUMN fecha_devolucion_real TEXT"
                )

            # Índice auxiliar para consultas de préstamos activos.
            connection.execute("""
                CREATE INDEX IF NOT EXISTS idx_prestamos_equipo_estado
                ON prestamos(equipo_id, estado)
            """)
