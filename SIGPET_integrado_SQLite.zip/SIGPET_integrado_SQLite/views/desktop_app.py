import tkinter as tk
from tkinter import ttk, messagebox

from controllers.inventario_controller import InventarioController
from controllers.prestamos_controller import (
    PrestamosController,
    ReglaNegocioError
)


class SigpetDesktopApp:
    """Interfaz gráfica SIGPET conectada a los controladores SQLite."""

    def __init__(self, root, database):
        self.root = root
        self.database = database

        self.root.title(
            "SIGPET - Sistema de Gestión de Préstamos de Equipos Tecnológicos"
        )
        self.root.geometry("900x600")
        self.root.minsize(750, 500)

        self.bg_color = "#F4F6F9"
        self.primary_color = "#173B65"
        self.secondary_color = "#245A91"

        self.inventario_controller = InventarioController(database)
        self.prestamos_controller = PrestamosController(database)

        self.root.configure(bg=self.bg_color)
        self.configure_styles()
        self.init_header()
        self.init_notebook()

    def configure_styles(self):
        style = ttk.Style()
        style.theme_use("clam")

        style.configure("TFrame", background=self.bg_color)
        style.configure(
            "TLabel", background=self.bg_color,
            font=("Segoe UI", 10)
        )
        style.configure(
            "Title.TLabel", background=self.primary_color,
            foreground="white", font=("Segoe UI", 17, "bold")
        )
        style.configure(
            "Subtitle.TLabel", background=self.primary_color,
            foreground="#DCE6F1", font=("Segoe UI", 9)
        )
        style.configure(
            "TButton", font=("Segoe UI", 10, "bold"), padding=8
        )
        style.configure(
            "Primary.TButton", background=self.primary_color,
            foreground="white", padding=10
        )
        style.map(
            "Primary.TButton",
            background=[("active", self.secondary_color),
                        ("pressed", self.secondary_color)],
            foreground=[("active", "white")]
        )
        style.configure(
            "TNotebook", background=self.bg_color, borderwidth=0
        )
        style.configure(
            "TNotebook.Tab", padding=(15, 9),
            font=("Segoe UI", 10, "bold")
        )
        style.map(
            "TNotebook.Tab",
            background=[("selected", self.primary_color)],
            foreground=[("selected", "white")]
        )
        style.configure(
            "Treeview", background="white", foreground="#333333",
            rowheight=30, font=("Segoe UI", 9), fieldbackground="white"
        )
        style.configure(
            "Treeview.Heading", background=self.primary_color,
            foreground="white", font=("Segoe UI", 9, "bold"), padding=8
        )

    def init_header(self):
        header = tk.Frame(self.root, bg=self.primary_color, height=85)
        header.pack(fill="x")
        header.pack_propagate(False)

        ttk.Label(
            header, text="SIGPET", style="Title.TLabel"
        ).pack(anchor="w", padx=20, pady=(12, 0))

        ttk.Label(
            header,
            text=("Sistema de Gestión de Préstamos de Equipos Tecnológicos"
                  " | Universidad Técnica de Cotopaxi"),
            style="Subtitle.TLabel"
        ).pack(anchor="w", padx=20)

    def init_notebook(self):
        container = ttk.Frame(self.root, padding=15)
        container.pack(fill="both", expand=True)

        self.notebook = ttk.Notebook(container)
        self.notebook.pack(fill="both", expand=True)

        self.tab_inventario = ttk.Frame(self.notebook, padding=15)
        self.tab_prestamos = ttk.Frame(self.notebook, padding=20)
        self.tab_devoluciones = ttk.Frame(self.notebook, padding=20)

        self.notebook.add(self.tab_inventario, text="Inventario de Equipos")
        self.notebook.add(self.tab_prestamos, text="Gestión de Préstamos")
        self.notebook.add(self.tab_devoluciones, text="Devoluciones")

        self.init_inventario()
        self.init_prestamos()
        self.init_devoluciones()

    # -------------------- INVENTARIO --------------------

    def init_inventario(self):
        ttk.Label(
            self.tab_inventario,
            text="Inventario de Equipos Tecnológicos",
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 15))

        ttk.Label(
            self.tab_inventario,
            text="Registros consultados directamente desde la base de datos."
        ).pack(anchor="w", pady=(0, 10))

        table_frame = ttk.Frame(self.tab_inventario)
        table_frame.pack(fill="both", expand=True)

        columns = ("id", "codigo", "nombre", "categoria", "estado")
        self.tree = ttk.Treeview(
            table_frame, columns=columns, show="headings"
        )

        config = {
            "id": ("ID", 55, "center"),
            "codigo": ("Código", 120, "center"),
            "nombre": ("Nombre", 200, "w"),
            "categoria": ("Categoría", 150, "w"),
            "estado": ("Estado", 130, "center"),
        }
        for column, (heading, width, anchor) in config.items():
            self.tree.heading(column, text=heading)
            self.tree.column(column, width=width, anchor=anchor)

        scrollbar = ttk.Scrollbar(
            table_frame, orient="vertical", command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        ttk.Button(
            self.tab_inventario, text="Refrescar Inventario",
            style="Primary.TButton", command=self.refresh_inventory
        ).pack(anchor="e", pady=15)

        self.refresh_inventory(show_message=False)

    def refresh_inventory(self, show_message=True):
        try:
            records = self.inventario_controller.obtener_equipos()

            for item in self.tree.get_children():
                self.tree.delete(item)

            for record in records:
                self.tree.insert("", "end", values=record)

            if show_message:
                messagebox.showinfo(
                    "Inventario",
                    f"Inventario actualizado. Registros encontrados: {len(records)}."
                )
        except Exception as error:
            messagebox.showerror(
                "Error de consulta",
                "No fue posible consultar el inventario.\n\n"
                f"Detalle: {error}"
            )

    # -------------------- PRÉSTAMOS --------------------

    def init_prestamos(self):
        ttk.Label(
            self.tab_prestamos, text="Registro de Préstamos",
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 20))

        form = ttk.Frame(self.tab_prestamos)
        form.pack(fill="x", padx=10)

        self.entry_equipo = self.add_form_entry(form, "ID del Equipo:", 0)
        self.entry_usuario = self.add_form_entry(form, "ID del Usuario:", 1)
        self.entry_fecha = self.add_form_entry(
            form, "Fecha de Devolución Esperada:", 2
        )
        self.entry_observaciones = self.add_form_entry(
            form, "Observaciones:", 3
        )

        self.entry_fecha.insert(0, "2026-12-15 17:00")
        form.columnconfigure(1, weight=1)

        ttk.Button(
            self.tab_prestamos, text="Guardar Préstamo",
            style="Primary.TButton", command=self.save_loan
        ).pack(anchor="e", padx=10, pady=25)

        ttk.Label(
            self.tab_prestamos,
            text="Formato de fecha: YYYY-MM-DD HH:MM",
            foreground="#666666"
        ).pack(anchor="w", padx=10)

    def save_loan(self):
        equipo_id = self.entry_equipo.get().strip()
        usuario_id = self.entry_usuario.get().strip()
        fecha = self.entry_fecha.get().strip()
        observaciones = self.entry_observaciones.get().strip()

        if not equipo_id or not usuario_id or not fecha:
            messagebox.showwarning(
                "Validación",
                "ID del Equipo, ID del Usuario y Fecha de Devolución "
                "son campos obligatorios."
            )
            return

        try:
            prestamo_id = self.prestamos_controller.guardar_prestamo(
                equipo_id, usuario_id, fecha, observaciones
            )

            messagebox.showinfo(
                "Préstamo registrado",
                f"Préstamo registrado correctamente.\n\n"
                f"Número de préstamo: {prestamo_id}\n"
                f"Equipo: {equipo_id}\nUsuario: {usuario_id}"
            )

            self.entry_equipo.delete(0, tk.END)
            self.entry_usuario.delete(0, tk.END)
            self.entry_fecha.delete(0, tk.END)
            self.entry_observaciones.delete(0, tk.END)
            self.refresh_inventory(show_message=False)

        except (ValueError, ReglaNegocioError) as error:
            messagebox.showerror("No se pudo registrar el préstamo", str(error))
        except Exception as error:
            messagebox.showerror(
                "Error de base de datos",
                "Ocurrió un problema al guardar el préstamo. "
                "La transacción fue cancelada.\n\n"
                f"Detalle: {error}"
            )

    # -------------------- DEVOLUCIONES --------------------

    def init_devoluciones(self):
        ttk.Label(
            self.tab_devoluciones, text="Procesamiento de Devoluciones",
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 20))

        form = ttk.Frame(self.tab_devoluciones)
        form.pack(fill="x", padx=10)

        self.entry_prestamo_id = self.add_form_entry(
            form, "ID del Préstamo Activo:", 0
        )
        self.entry_obs_devolucion = self.add_form_entry(
            form, "Observaciones de Devolución:", 1
        )
        form.columnconfigure(1, weight=1)

        ttk.Button(
            self.tab_devoluciones, text="Procesar Devolución",
            style="Primary.TButton", command=self.process_return
        ).pack(anchor="e", padx=10, pady=25)

    def process_return(self):
        prestamo_id = self.entry_prestamo_id.get().strip()
        observaciones = self.entry_obs_devolucion.get().strip()

        if not prestamo_id:
            messagebox.showwarning(
                "Validación", "Debe ingresar el ID del préstamo activo."
            )
            return

        try:
            result = self.prestamos_controller.procesar_devolucion(
                prestamo_id, observaciones
            )

            messagebox.showinfo(
                "Devolución procesada",
                "Devolución registrada correctamente.\n\n"
                f"Préstamo: {result['prestamo_id']}\n"
                f"Equipo liberado: {result['equipo_id']}\n"
                f"Fecha real: {result['fecha_devolucion_real']}"
            )

            self.entry_prestamo_id.delete(0, tk.END)
            self.entry_obs_devolucion.delete(0, tk.END)
            self.refresh_inventory(show_message=False)

        except (ValueError, ReglaNegocioError) as error:
            messagebox.showerror("No se pudo procesar la devolución", str(error))
        except Exception as error:
            messagebox.showerror(
                "Error de base de datos",
                "Ocurrió un problema al procesar la devolución. "
                "La transacción fue cancelada.\n\n"
                f"Detalle: {error}"
            )

    # -------------------- UTILIDAD DE FORMULARIOS --------------------

    @staticmethod
    def add_form_entry(parent, label_text, row):
        ttk.Label(parent, text=label_text).grid(
            row=row, column=0, sticky="w", pady=12
        )
        entry = ttk.Entry(parent, width=45)
        entry.grid(
            row=row, column=1, sticky="ew", padx=15, pady=12
        )
        return entry
