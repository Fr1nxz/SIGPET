import tkinter as tk
from tkinter import messagebox

from database.connection import DatabaseConnection
from views.desktop_app import SigpetDesktopApp


def main():
    root = tk.Tk()
    database = DatabaseConnection()

    try:
        database.initialize()
    except Exception as error:
        messagebox.showerror(
            "Error de base de datos",
            "No fue posible inicializar la base de datos SIGPET.\n\n"
            f"Detalle: {error}"
        )
        root.destroy()
        return

    SigpetDesktopApp(root, database)
    root.mainloop()


if __name__ == "__main__":
    main()
