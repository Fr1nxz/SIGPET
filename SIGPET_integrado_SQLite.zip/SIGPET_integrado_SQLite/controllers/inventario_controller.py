class InventarioController:
    """Consulta los equipos almacenados en la base de datos."""

    def __init__(self, database):
        self.database = database

    def obtener_equipos(self):
        """
        Obtiene el inventario real mediante SELECT.
        Devuelve tuplas compatibles con ttk.Treeview.
        """
        query = """
            SELECT id, codigo, nombre, categoria, estado
            FROM equipos
            ORDER BY id
        """
        connection = self.database.connect()
        try:
            rows = connection.execute(query).fetchall()
            return [
                (
                    row["id"],
                    row["codigo"],
                    row["nombre"],
                    row["categoria"],
                    row["estado"]
                )
                for row in rows
            ]
        finally:
            connection.close()
