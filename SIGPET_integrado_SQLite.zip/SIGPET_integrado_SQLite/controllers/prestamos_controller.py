from datetime import datetime
import sqlite3


class ReglaNegocioError(Exception):
    """Error controlado por incumplimiento de una regla del sistema."""


class PrestamosController:
    """Reglas de negocio y transacciones de préstamos/devoluciones."""

    def __init__(self, database):
        self.database = database

    @staticmethod
    def validar_identificador(valor, nombre_campo):
        try:
            identificador = int(valor)
            if identificador <= 0:
                raise ValueError
            return identificador
        except (TypeError, ValueError):
            raise ValueError(
                f"{nombre_campo} debe ser un número entero positivo."
            )

    @staticmethod
    def validar_fecha(fecha):
        try:
            parsed = datetime.strptime(fecha, "%Y-%m-%d %H:%M")
            return parsed.strftime("%Y-%m-%d %H:%M")
        except (TypeError, ValueError):
            raise ValueError(
                "La fecha debe tener el formato YYYY-MM-DD HH:MM "
                "(ejemplo: 2026-12-15 17:00)."
            )

    def guardar_prestamo(self, equipo_id, usuario_id, fecha, observaciones=""):
        equipo_id = self.validar_identificador(equipo_id, "ID del equipo")
        usuario_id = self.validar_identificador(usuario_id, "ID del usuario")
        fecha = self.validar_fecha(fecha)

        connection = self.database.connect()
        try:
            # BEGIN IMMEDIATE obtiene el bloqueo de escritura antes de comprobar
            # disponibilidad. Evita que dos operaciones concurrentes asignen
            # el mismo equipo simultáneamente en SQLite.
            connection.execute("BEGIN IMMEDIATE")

            equipo = connection.execute(
                "SELECT id, estado FROM equipos WHERE id = ?",
                (equipo_id,)
            ).fetchone()

            if equipo is None:
                raise ReglaNegocioError(
                    f"No existe un equipo con ID {equipo_id}."
                )

            if (equipo["estado"] or "").strip().upper() != "DISPONIBLE":
                raise ReglaNegocioError(
                    f"El equipo {equipo_id} no está DISPONIBLE. "
                    f"Estado actual: {equipo['estado']}."
                )

            # Actualización condicional adicional como protección.
            cursor = connection.execute(
                """
                UPDATE equipos
                SET estado = 'PRESTADO'
                WHERE id = ? AND UPPER(TRIM(estado)) = 'DISPONIBLE'
                """,
                (equipo_id,)
            )

            if cursor.rowcount != 1:
                raise ReglaNegocioError(
                    "El equipo dejó de estar disponible. "
                    "Actualice el inventario e inténtelo nuevamente."
                )

            cursor = connection.execute(
                """
                INSERT INTO prestamos (
                    equipo_id,
                    usuario_id,
                    fecha_devolucion_esperada,
                    observaciones,
                    estado
                )
                VALUES (?, ?, ?, ?, 'ACTIVO')
                """,
                (equipo_id, usuario_id, fecha, observaciones)
            )
            prestamo_id = cursor.lastrowid

            connection.commit()
            return prestamo_id

        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.close()

    def procesar_devolucion(self, prestamo_id, observaciones=""):
        prestamo_id = self.validar_identificador(
            prestamo_id, "ID del préstamo"
        )
        fecha_real = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        connection = self.database.connect()
        try:
            connection.execute("BEGIN IMMEDIATE")

            prestamo = connection.execute(
                """
                SELECT id, equipo_id, estado
                FROM prestamos
                WHERE id = ?
                """,
                (prestamo_id,)
            ).fetchone()

            if prestamo is None:
                raise ReglaNegocioError(
                    f"No existe un préstamo con ID {prestamo_id}."
                )

            if (prestamo["estado"] or "").strip().upper() != "ACTIVO":
                raise ReglaNegocioError(
                    f"El préstamo {prestamo_id} no está activo "
                    "o ya fue devuelto."
                )

            equipo_id = prestamo["equipo_id"]

            cursor = connection.execute(
                """
                UPDATE prestamos
                SET estado = 'DEVUELTO',
                    fecha_devolucion_real = ?
                WHERE id = ? AND UPPER(TRIM(estado)) = 'ACTIVO'
                """,
                (fecha_real, prestamo_id)
            )

            if cursor.rowcount != 1:
                raise ReglaNegocioError(
                    "No se pudo actualizar el préstamo. "
                    "Verifique su estado e inténtelo nuevamente."
                )

            connection.execute(
                """
                INSERT INTO devoluciones (
                    prestamo_id, fecha_devolucion, observaciones
                )
                VALUES (?, ?, ?)
                """,
                (prestamo_id, fecha_real, observaciones)
            )

            cursor = connection.execute(
                """
                UPDATE equipos
                SET estado = 'DISPONIBLE'
                WHERE id = ?
                """,
                (equipo_id,)
            )

            if cursor.rowcount != 1:
                raise ReglaNegocioError(
                    "No se encontró el equipo asociado al préstamo. "
                    "La devolución no fue confirmada."
                )

            connection.commit()
            return {
                "prestamo_id": prestamo_id,
                "equipo_id": equipo_id,
                "fecha_devolucion_real": fecha_real
            }

        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.close()
