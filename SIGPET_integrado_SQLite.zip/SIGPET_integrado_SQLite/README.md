# SIGPET - Sistema de Gestión de Préstamos de Equipos Tecnológicos

## Requisitos
- Python 3.9 o superior.
- Tkinter (incluido normalmente en Python para Windows).
- No requiere instalar paquetes externos: usa `sqlite3`, incluido en Python.

## Ejecución
Desde la carpeta raíz del proyecto:

```bash
python main.py
```

Al iniciar, se crea automáticamente `database/sigpet.db` y las tablas necesarias.

## Estructura

```text
SIGPET/
├── main.py
├── database/
│   ├── __init__.py
│   └── connection.py
├── controllers/
│   ├── __init__.py
│   ├── inventario_controller.py
│   └── prestamos_controller.py
└── views/
    ├── __init__.py
    └── desktop_app.py
```

## Tablas utilizadas

### equipos
- `id`
- `codigo`
- `nombre`
- `categoria`
- `estado`

### prestamos
- `id`
- `equipo_id`
- `usuario_id`
- `fecha_devolucion_esperada`
- `observaciones`
- `estado`
- `fecha_devolucion_real`

### devoluciones
- `id`
- `prestamo_id`
- `fecha_devolucion`
- `observaciones`

## Reglas transaccionales

- El préstamo comprueba que el equipo exista y su estado sea `DISPONIBLE`.
- La reserva del equipo y el INSERT del préstamo se ejecutan en una misma transacción.
- SQLite usa `BEGIN IMMEDIATE` para serializar las operaciones de escritura y evitar
  asignaciones simultáneas del mismo equipo.
- La devolución verifica que el préstamo esté `ACTIVO`, registra la fecha real,
  cambia el préstamo a `DEVUELTO` y libera el equipo a `DISPONIBLE`.
- Si ocurre un error, se ejecuta `ROLLBACK` y no se confirma parcialmente la operación.

## Importante: datos iniciales

La base se crea vacía. Para que el inventario muestre equipos, registre equipos
en la tabla `equipos` usando un gestor SQLite o una herramienta de administración.

Ejemplo SQL:

```sql
INSERT INTO equipos (codigo, nombre, categoria, estado)
VALUES ('EQ-001', 'Laptop Dell', 'Computación', 'DISPONIBLE');
```

Para probar préstamos, el `usuario_id` se valida como entero positivo, pero todavía
no existe una tabla de usuarios ni una clave foránea hacia ella. Esa integración
puede añadirse en la siguiente etapa.

La base SQLite se guarda en `database/sigpet.db`.
